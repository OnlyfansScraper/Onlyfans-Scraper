class config(object):
    def __init__(self, ofd_directory=""):
        self.ofd_directory = ofd_directory
